﻿namespace App.Core.DTO.Command
{
    /// <summary>
    /// Objeto de transferencia de información para
    /// la entidad comentario
    /// </summary>
    public class ComentarioDTO
    {
        public string Texto { get; set; }
    }
}
