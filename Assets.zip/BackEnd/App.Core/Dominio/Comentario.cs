﻿namespace App.Core.Dominio
{
    /// <summary>
    /// Entidad de dominio 
    /// Comentario
    /// </summary>
    public class Comentario : TextoItem
    {
        public int PostId { get; set; }
    }
}
