﻿namespace App.Core.Dominio.Errors
{
    /// <summary>
    /// Estructura de datos para el manejo de errores
    /// </summary>
    public class ErrorApp
    {
        public string Mensaje { get; set; }
        public ErrorApp()
        {

        }
    }
}
